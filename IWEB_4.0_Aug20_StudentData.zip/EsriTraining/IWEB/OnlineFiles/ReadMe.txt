This folder should contain the following:
� A copy of each file students should reference online IN CASE access to the online file is unavailable.

Delete this folder if students do not reference online files in the course.